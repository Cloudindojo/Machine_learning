from flask import Flask, render_template,  request, redirect, url_for, send_from_directory, flash
import os
import sys
from pymongo import MongoClient

app = Flask(__name__)

connection = MongoClient("localhost", 27017)
db = connection.mydatabase 
mla=db.mla
mp=db.mp
user=db.user
meetings=db.meetings
comments1=db.usercomments

@app.route('/')
def index():
   return render_template('login_form.html')

@app.route('/login', methods=['GET','POST'])
def login():
	if request.method == 'POST':
		un = str(request.form['UserName'])
		p = str(request.form['Password'])
		radio=str(request.form['contact'])
		if radio == "admin":
			if un=="admin" and p=="admin":
				adu=[]
				adml=[]
				admp=[]
				for i in user.find():
					adu.append(i)
				for j in mla.find():
					if j['designation'] == 'mla':
						adml.append(j)
					else:
						admp.append(j)
				return render_template("home.html", user1=adu, mla=adml, mp=admp)
			else:
				return render_template('login_form.html', data="authentication failed")
		elif radio == "mla":
			for i in mla.find():
				if i['designation'] == 'mla':
					if un==i["username"] and p==i["password"]:
						ml=[]
						for i in user.find():
							ml.append(i)
						return render_template("mla.html", ml=ml)
					
			return render_template('login_form.html', data="authentication failed to mla")
		elif radio == "mp":
			for i in mla.find():
				if i['designation'] == 'mp':
					if un==i["username"] and p==i["password"]:
						ml=[]
						for i in user.find():
							ml.append(i)
						return render_template("mp.html")
				
			return render_template('login_form.html', data="authentication failed to mp")
		elif radio == "user":
			for i in user.find():
				if un==i["UserName"] and p==i["Password"]:
					return render_template("user.html")
				
			return render_template('login_form.html', data="authentication failed")
		else:
			return render_template('login_form.html', data="select raido button")
	else:
		return render_template("login_form.html")
@app.route('/mlampreg', methods=['GET','POST'])
def mlampreg():
	if request.method == 'POST':
		radio=str(request.form['contact1'])
		firstName=str(request.form['First_Name'])
		lastName=str(request.form['Last_Name'])
		dob=str(request.form.get('Birthday_day'))+"/"+str(request.form.get('Birthday_Month'))+"/"+str(request.form.get('Birthday_Year'))
		email=str(request.form['Email_Id'])
		phno=str(request.form['Mobile_Number'])
		Gender=str(request.form['Gender'])
		username=str(request.form['username'])
		password=str(request.form['password'])
		address=str(request.form['Address'])
		consistency=str(request.form['consistency'])
		city=str(request.form['City'])
		pincode=str(request.form['Pin_Code'])
		state=str(request.form['State'])
		country=str(request.form['Country'])
		mladata={"designation":radio, "firstName":firstName,"lastName":lastName,"dob":dob,"email":email,"phno":phno,"Gender":Gender,"username":username,"password":password,"address":address,"consistency":consistency,"city":city,"pincode":pincode,"state":state,"country":country}
		mla.insert_one(mladata)
		return render_template('mlampreg.html', da="sucess")
	else:
		return render_template('mlampreg.html')

@app.route('/register', methods=['GET','POST'])
def register():
	if request.method == 'POST':
		un = request.form['UserName']
		fn = request.form['FirstName']
		ln = request.form['LastName']
		d = request.form['Date']
		g = request.form['Gmail']
		p = request.form['Password']
		cp = request.form['ConfirmPassword']
		m =  request.form['MobileNumber']
		r = request.form['gridRadios']
		a = request.form['Address']
		cs = request.form['Consistency']
		c = request.form['City']
		pc = request.form['Pincode']
		st = request.form['State']
		ct = request.form['Country']
		
		userdata = {'UserName': un, 'FirstName': fn, 'LastName':ln, 'Date':d, 'Gmail':g, 'Password': cp, 'Gender': r, 'Address':a, 'Consistency':cs, 'City':c, 'Pincode':pc, 
		'State':st, 'Country':ct}
		user.insert_one(userdata)
		return redirect('login')
	return render_template('Registration_form.html')

@app.route('/meetingdetails', methods=['GET','POST'])
def meetingdetails():
	if request.method == 'POST':
		place=request.form['place']
		date=request.form['date']
		time=request.form['time']
		purpose=request.form['purpose']
		meetingdetails1={'place':place, 'date':date, 'time':time, 'purpose':purpose}
		meetings.insert_one(meetingdetails1)
		return render_template('meetingdetails.html', data='sucess')
	else:
		return render_template('meetingdetails.html')
	

@app.route('/meets', methods=['GET','POST'])
def meets():
	ls=[]
	for i in meetings.find():
		ls.append(i)
	if request.method == 'POST':
		comment=request.form['comment']
		cc={"comment":comment}
		comments1.insert_one(cc)
		return render_template('meatings.html', meetings1=ls)
	else:
		return render_template('meatings.html', meetings1=ls)


@app.route('/logout', methods=['GET','POST'])
def logout():
	return render_template('login_form.html')

if __name__ == '__main__':
   app.run(debug = True)